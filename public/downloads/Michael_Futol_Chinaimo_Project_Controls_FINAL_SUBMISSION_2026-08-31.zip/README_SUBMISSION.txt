MICHAEL FUTOL - CHINAIMO PROJECT CONTROLS TECHNICAL ASSESSMENT
Website: https://michael-futol-chinaimo-project-cont.vercel.app/

Assessment Data Date: 31-Aug-2026
Native CPM: Baseline 15-Feb-2028 | Current Forecast 23-Jun-2028 (+111 wd) | Partial Recovery 14-Apr-2028 (60 wd recovered; 51 wd residual)
Public July-2028 completion target is a separate public reference.
Public progress checkpoint: 4.19% at 05-May-2026.
12.095% at 31-Aug-2026 is assessment-simulated and is not represented as Kubota actual progress.

Authority:
- Native MPPs govern schedule logic / CPM dates.
- Final Master Excel governs assessment BOQ/value/progress/recovery/IPC control.
- Schedule Logic & S-Curve Annex supports predecessor logic and comparative curves.
- English Word is reviewer explanatory support.
